package org.cap.demo;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	
		public static void main(String[] args) {
			EntityManagerFactory emf=
					Persistence.createEntityManagerFactory("jpademo");
			EntityManager entityManager =emf.createEntityManager();
			EntityTransaction transaction=entityManager.getTransaction();
			
			transaction.begin(); 
	        customer cust=new customer(1,"Sam",200,new Date("1997-04-24"));
			//customer cust1=new customer(2,"Samu",300,"1997-05-25");
			//customer cust2=new customer(3,"Sami",400,"1997-06-26");
			
			//INSERT QUERY
			entityManager.persist(cust);
			//entityManager.persist(cust1);
			//entityManager.persist(cust2);
		
			transaction.commit();
		}
	
	 

	}


