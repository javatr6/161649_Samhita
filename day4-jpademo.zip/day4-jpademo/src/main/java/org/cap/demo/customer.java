package org.cap.demo;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class customer {
	@Id
	private int custId;
	private String custName;
	private Integer regFees;
	private Date regDate;
	
	
public customer(){
	
}


public customer(int custId, String custName, Integer regFees, Date regDate) {
	super();
	this.custId = custId;
	this.custName = custName;
	this.regFees = regFees;
	this.regDate = regDate;
}


public int getCustId() {
	return custId;
}


public void setCustId(int custId) {
	this.custId = custId;
}


public String getCustName() {
	return custName;
}


public void setCustName(String custName) {
	this.custName = custName;
}


public Integer getRegFees() {
	return regFees;
}


public void setRegFees(Integer regFees) {
	this.regFees = regFees;
}


public Date getRegDate() {
	return regDate;
}


public void setRegDate(Date regDate) {
	this.regDate = regDate;
} 
 

}
