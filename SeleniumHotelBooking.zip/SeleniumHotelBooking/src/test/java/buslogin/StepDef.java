package buslogin;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {           

	private WebDriver webDriver;
	private WebElement webElement;
	
@Before	
public void setUp() {
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\sdasyam\\Desktop\\chromedriver.exe");
	webDriver=new ChromeDriver();
}
	
	@Given("^For valid login details$")
	public void for_valid_login_details() throws Throwable {
		webDriver.get("http://localhost:8081/161649Samhita_BusPassRequest/pages/index1.html?");
	  
	}

	@When("^Entered correct name and password$")
	public void entered_correct_name_and_password() throws Throwable {
		
		
		webDriver.findElement(By.name("username")).sendKeys("sam");
		webDriver.findElement(By.name("password")).sendKeys("sam123");
	}

	@Then("^Validate the credentials$")
	public void validate_the_credentials() throws Throwable {
		webElement=webDriver.findElement(By.name("login"));
		webElement.submit();
	}

	@Then("^Redirect to next page$")
	public void redirect_to_next_page() throws Throwable {
		webDriver.navigate().to("http://localhost:8081/161649Samhita_BusPassRequest/pages/menu.html?");
			
		webDriver.quit();
	}


}
