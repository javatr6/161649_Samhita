package com.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {

	private static int delegateId;
	private static String delegateName;

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
			transaction.begin(); 
			
			
			Events java=new Events();
			java.setEventId("101-JAVA");
			java.setEventName("JAVA");
			
			Events oracle=new Events();
			oracle.setEventId("102-ORACLE");
			oracle.setEventName("ORACLE");
			
			Events C=new Events();
			C.setEventId("103-C");
			C.setEventName("C");
			
			
			Delegates delegates=new Delegates(delegateId,delegateName);
			
			Delegates sam=new Delegates(10,"sam");
			Delegates mam=new Delegates(20,"mam");
			Delegates mom=new Delegates(30,"mom");
			Delegates dom=new Delegates(40,"dom");
			
			sam.getEvents().add(java);
			sam.getEvents().add(oracle);
			sam.getEvents().add(C);
			
			mam.getEvents().add(java);
			dom.getEvents().add(java);
			
			mom.getEvents().add(C);
			mam.getEvents().add(C);
			
			dom.getEvents().add(oracle);
			
			
			entityManager.persist(sam);
			entityManager.persist(mam);
			entityManager.persist(mom);
			entityManager.persist(dom);
			entityManager.persist(java);
			entityManager.persist(oracle);
			entityManager.persist(C);
			
			transaction.commit();
			entityManager.close();

	}

}
